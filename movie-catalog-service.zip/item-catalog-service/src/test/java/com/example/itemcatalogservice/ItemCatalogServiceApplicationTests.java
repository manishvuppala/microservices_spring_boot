package com.example.itemcatalogservice;

import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
