package com.example.iteminfoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
